﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WFComercialWebApp.Models;
using Bitacora;
using NLog;
using Microsoft.Office.Interop;

namespace WFComercialWebApp.Controllers
{
    public class HomeController : Controller
    {
        private RiesgosComercialesEntities db = new RiesgosComercialesEntities();
        [HttpGet]
        [AllowAnonymous]
        public ActionResult Index()
        {
            ViewBag.login = "";
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CheckUser(string user, string pass)
        {
            try
            {
                Usuario usuario = db.Usuario.First(u => u.NombreUsuario == user.ToUpper());
                if (usuario.Cargo != "")
                {
                    ViewBag.login = usuario.Nombre;
                    return RedirectToAction("Index", "Operacion");
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            catch (Exception ex)
            {
                return RedirectToAction("Index", "Home");
            }
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Docs()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult Reportes()
        {
            return View();
        }

    }
}