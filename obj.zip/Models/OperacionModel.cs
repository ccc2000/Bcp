﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WFComercialWebApp.Models
{
    public class OperacionModel
    {
    }

    public class List_Ope_Model
    {
        public string OperacionID { get; set; }
        public string Fecha { get; set; }
        public string Cliente { get; set; }
        public string Tipo { get; set; }
        public string Estado { get; set; }
        public string Banca { get; set; }
        public string Region { get; set; }
    }
}